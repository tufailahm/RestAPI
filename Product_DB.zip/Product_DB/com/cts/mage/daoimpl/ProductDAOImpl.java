package com.cts.mage.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.mage.connection.DBConnection;
import com.cts.mage.dao.ProductDAO;
import com.cts.mage.model.Product;

public class ProductDAOImpl implements ProductDAO
{

	Connection conn = DBConnection.getConnection();
	public boolean addProduct(Product product)
	{
		PreparedStatement stat;
		boolean result = false;
		try {
			stat = conn.prepareStatement("insert into product values(?,?,?,?)");
			stat.setInt(1,product.getProductId());
			stat.setString(2,product.getProductName());
			stat.setInt(3,product.getQoh());
			stat.setInt(4,product.getPrice());
			int rows = stat.executeUpdate();
			if(rows == 0) {
				result = false;
			}
			else {
				result = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
		
	}
	@Override
	public boolean deleteProduct(int productId) {
		PreparedStatement stat;
		boolean result = false;
		try {
			stat = conn.prepareStatement("delete from product where productId = ?");
			stat.setInt(1,productId);
			int rows = stat.executeUpdate();
			if(rows == 0) {
				result = false;
			}
			else {
				result = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public boolean updateProduct(Product product) {
		PreparedStatement stat;
		boolean result = false;
		try {
			stat = conn.prepareStatement("update product set productName = ?, qoh = ? , price = ? where productId = ?");
			stat.setInt(4,product.getProductId());
			stat.setString(1,product.getProductName());
			stat.setInt(2,product.getQoh());
			stat.setInt(3,product.getPrice());
			int rows = stat.executeUpdate();
			if(rows == 0) {
				result = false;
			}
			else {
				result = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public boolean isProductExists(int productId) {
		PreparedStatement stat;
		boolean result = false;
		try {
			stat = conn.prepareStatement("select * from product where productId = ?");
			stat.setInt(1,productId);
			ResultSet res = stat.executeQuery();
			if(res.next()) {
				result = true;
			}
			else {
				result = false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public Product getProduct(int productId) {
		PreparedStatement stat;
		boolean result = false;
		Product product = new Product();
		try {
			stat = conn.prepareStatement("select * from product where productId = ?");
			stat.setInt(1,productId);
			ResultSet res = stat.executeQuery();
			if(res.next()) {
				product.setProductId(res.getInt(1));
				product.setProductName(res.getString(2));
				product.setQoh(res.getInt(3));
				product.setPrice(res.getInt(4));
			}
			else {
				result = false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return product;
	}
	@Override
	public List<Product> getAllProducts() {
		PreparedStatement stat;
		List<Product> products = new ArrayList<Product>();
		boolean result = false;
		Product product = new Product();
		try {
			stat = conn.prepareStatement("select * from product");
			ResultSet res = stat.executeQuery();
			while(res.next())
			{
				product.setProductId(res.getInt(1));
				product.setProductName(res.getString(2));
				product.setQoh(res.getInt(3));
				product.setPrice(res.getInt(4));
				products.add(product);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return products;
	}
}
