Create table product
(
	productId int
	productName varchar(20),
	qoh int,
	price int
)

--

Add mysql jar file in build path